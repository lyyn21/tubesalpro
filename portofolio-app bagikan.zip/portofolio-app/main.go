package main

import "portofolio-app/handler"

func main() {
	handler.RunApp()
}
